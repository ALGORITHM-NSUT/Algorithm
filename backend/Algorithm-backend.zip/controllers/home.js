
export const home = (req,res)=>{
    res.json({
        message: "Hello Saumil"
    })
}